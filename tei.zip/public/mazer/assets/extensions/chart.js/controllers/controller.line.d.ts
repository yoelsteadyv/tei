export default class LineController extends DatasetController {
    static id: string;
    /**
     * @type {any}
     */
    static overrides: any;
    update(mode: any): void;
    /**
       * @protected
       */
    protected getMaxOverflow(): any;
}
import DatasetController from "../core/core.datasetController.js";
